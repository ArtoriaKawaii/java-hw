package com.javacodegeeks.patterns.factorymethodpattern;

public class ErrorXMLParser implements XMLParser{//實體物件

	@Override
	public String parse() {
		System.out.println("Parsing error XML...");
		return "Error XML Message";
	}

}
