import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;

public class HW8_main {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        while (true) {
            try {
                int option;
                System.out.println("Select Adventure map(1: Forest 2: Grassland)");
                option = input.nextInt();
                if (option != 1 && option != 2) {
                    System.out.println("Invalid map. Wait until update!");
                    continue;
                }
                Adventure adventure = new Adventure();
                List catchList = adventure.CatchScenes(adventure.Encounter(option));
                System.out.println("My pokemon list : ");
                for(int i = 0; i < catchList.size(); i++)
                    System.out.println("\n" + catchList.get(i).toString());
                return;
            }catch(InputMismatchException e){
                System.out.println("Invalid input. Enter integers.");
                input.nextLine();
            }
        }
    }
}
