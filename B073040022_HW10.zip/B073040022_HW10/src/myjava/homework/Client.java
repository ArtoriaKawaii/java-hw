package myjava.homework;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.util.InputMismatchException;

public class Client extends ATM implements Runnable{
    private Socket socket;//和Server進行連線

    private Client(String ip, int port){
        try{
            socket = new Socket(ip, port);
        }catch(IOException e){
            System.out.println("Connection fail");//出現例外(無法建立連線時)時，捕捉並顯示例外訊息
        }
    }

    @Override
    public void run() {
        if (socket != null) {//連線成功才繼續往下執行
            System.out.println("Connection Success");
            String option_str;
            int option;
            while (true) {
                System.out.println("(1) Sign In");
                System.out.println("(2) Create New Account");
                System.out.println("(3) Exit");
                System.out.println("-------------------------------------");
                try {
                    option_str = keyboard.next();
                    sendData(option_str);
                    option = Integer.parseInt(option_str);
                    switch (option) {
                        case 1: {
                            System.out.println("Input your account");
                            sendData(keyboard.next());
                            System.out.println("Input your password");
                            String password;
                            while (true) {//check password
                                password = keyboard.next();
                                if (!checkPasswordType(password))
                                    System.out.println("Password must be integers, try again");
                                else if (!checkPasswordLength(password))
                                    System.out.println("Password must consist of 6 digits, try again");
                                else
                                    break;
                            }
                            sendData(password);
                            if (getStreams().readUTF().equals("Sign in success")) {
                                System.out.println("Sign in success");
                                System.out.println("(1) Deposit");
                                System.out.println("(2) Withdraw");
                                System.out.println("(3) Balance");
                                System.out.println("(4) Exit");
                                System.out.println("-------------------------------------");
                                option_str = keyboard.next();
                                sendData(option_str);
                                option = Integer.parseInt(option_str);
                                switch (option) {
                                    case 1: {
                                        System.out.println("Input the amount money you want to deposit");
                                        String depositMoney = keyboard.next();
                                        int money = Integer.parseInt(depositMoney);
                                        sendData(depositMoney);
                                        System.out.println("Deposit $" + money + ", $" + getStreams().readUTF() + " is in your account");
                                        break;
                                    }
                                    case 2: {
                                        System.out.println("Input the amount you want to withdraw");
                                        String withdrawMoney = keyboard.next();
                                        int money = Integer.parseInt(withdrawMoney);
                                        sendData(withdrawMoney);
                                        String balance = getStreams().readUTF();
                                        if (balance.equals("-1"))
                                            System.out.println("Withdraw fail, balance not enough");
                                        else
                                            System.out.println("Withdraw $" + money + ", $" + balance + " is in your account");
                                        break;
                                    }
                                    case 3: {
                                        System.out.println("Balance: $" + getStreams().readUTF() + " is in your account");
                                        break;
                                    }
                                    case 4: {
                                        System.out.println("Log out...");
                                        break;
                                    }
                                    default:
                                        System.out.println("No such function");
                                        continue;
                                }
                            } else {
                                System.out.println("Wrong username or password");
                            }
                            break;
                        }
                        case 2: {
                            System.out.println("Input your account");
                            sendData(keyboard.next());
                            System.out.println("Input your password");
                            String password;
                            while (true) {
                                password = keyboard.next();
                                if (!checkPasswordType(password))
                                    System.out.println("Password must be integers, try again");
                                else if (!checkPasswordLength(password))
                                    System.out.println("Password must consist of 6 digits, try again");
                                else
                                    break;
                            }
                            sendData(password);
                            if (getStreams().readUTF().equals("Account already exist")) {
                                System.out.println("Account already exist");
                            } else {
                                System.out.println("Account establishment success");
                            }
                            break;
                        }
                        case 3:
                            System.out.println("End Client...");
                            closeConnection();
                            return;
                        default:
                            System.out.println("No such function");
                    }
                } catch (IOException e) {
                    System.out.println("Error occur sending data");
                } catch (InputMismatchException | NumberFormatException e) {
                    System.out.println("Input error");
                }
            }
        }
    }
    public void processConnection(){
        //didn't use
    }
    public void closeConnection(){//closing socket connection
        try{
            socket.close();
        }catch(IOException e){
            System.out.println("Error occur closing socket connection");
        }
    }
    public void sendData(String message) throws IOException{//sending data to Server
        DataOutputStream toServer = new DataOutputStream(socket.getOutputStream());
        toServer.writeUTF(message);
    }
    public DataInputStream getStreams() throws IOException{//get data streams from Server
        return new DataInputStream(socket.getInputStream());
    }
    private boolean checkPasswordType(String password){
        try{
            Integer.parseInt(password);
            return true;
        }catch (NumberFormatException e){
            return false;
        }
    }
    private boolean checkPasswordLength(String password){
        return password.length() == 6;
    }
    public static void main(String[] args) {
        try {
            System.out.println("Input your address");
            String ip = keyboard.next();
            System.out.println("Input your port");
            int port = keyboard.nextInt();
            System.out.println("Connecting...");
            new Thread(new Client(ip, port)).start();//建立物件，傳入IP和Port並執行等待接受連線的動作
        }catch (InputMismatchException e){
            System.out.println("Input error");
        }
    }
}
