package myjava.homework;

import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;
import java.util.StringTokenizer;

public class fourStarGame {
    private ArrayList<Integer> userNums = new ArrayList<>();
    private ArrayList<Integer> winNums = new ArrayList<>();
    public final int STARS = 4;
    public int flag;
    public fourStarGame(){
    }
    public void generateUserNums(){
        Scanner keyboard = new Scanner(System.in);
        System.out.print("Input four user numbers : ");
        StringTokenizer subString = new StringTokenizer(keyboard.nextLine(), " ", false);
        //use whitespace as delimiter, delimiter is not a part of token
        while(subString.hasMoreTokens()) {
            String num = subString.nextToken();
            for(int i = 0; i < num.length(); i++) {//Check if enter NOT digit
                if (!Character.isDigit(num.charAt(i))) {
                    System.out.println("Wrong input(numbers), try again.");
                    this.flag = -1;
                    return;
                }
            }
            if(Integer.parseInt(num) > 9 || Integer.parseInt(num) < 0){//check 0 <= number <= 9
                System.out.println("Wrong input(0~9), try again.");
                this.flag = -1;
                return;
            }
            userNums.add(Integer.parseInt(num));
        }
        if(userNums.size() != STARS) {//check if there were four numbers
            System.out.println("Wrong input(4 numbers), try again.");
            this.flag = -1;
        }
    }
    public void generateWinNums(){
        Random nums = new Random(System.currentTimeMillis());//use time as random seed
        int[] numUsed = new int[10];//non-duplicate
        for(int i = 0; i < STARS; i++){
            int num = nums.nextInt(10);
            if(numUsed[num] == 0){
                winNums.add(num);
                numUsed[num] = 1;
            }
            else
                i--;
        }
    }

    public ArrayList<Integer> getUserNums() {
        return new ArrayList<>(userNums);
    }

    public ArrayList<Integer> getWinNums() {
        return new ArrayList<>(winNums);
    }
}
