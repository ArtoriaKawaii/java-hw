package myjava.homework;

import java.util.Scanner;

public abstract class Pokemon implements skill{
    private int hp;
    private int atk;
    private int unique;
    protected Scanner input = new Scanner(System.in);
    protected boolean winFlag = false;

    public Pokemon(int hp, int atk, int unique){
        this.hp = hp;
        this.atk = atk;
        this.unique = unique;
    }

    public abstract int attack_skill();
    public abstract int defense_skill();
    public abstract int buff_skill();

    public int getHp() {
        return hp;
    }

    public int getAtk() {
        return atk;
    }

    public int getUnique() {
        return unique;
    }

    public void setHp(int hp) {
        if(hp < 0)
            this.hp = 0;
        else
            this.hp = hp;
    }

    public void setAtk(int atk) {
        this.atk = atk;
    }

    public void setUnique(int unique) {
        this.unique = unique;
    }

    public abstract int action();
    //return == 0 ends correctly)
    public abstract void getDamage(int wildPokemon_ATK);
}
