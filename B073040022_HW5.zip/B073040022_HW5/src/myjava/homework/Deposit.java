// Represents a deposit ATM transaction
package myjava.homework;

public class Deposit extends Transaction {
    public Deposit(int accountNumber){
        super(accountNumber);
    }
    public void execute(){
        int deposit;
        while(true) {
            output.displayMessage("How much do you want to deposit : ");
            deposit = input.getInput();
            if (deposit != -1)
                break;
            output.displayMessageLine("Input error.");
        }
        ATM.bankDatabase.setTotalBalance(getAccountNumber(), ATM.bankDatabase.getTotalBalance(getAccountNumber()) + deposit)  ;
        output.displayMessageLine("Transaction success.\n");
    }
}
