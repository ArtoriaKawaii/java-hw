package myjava.homework.part2;
import java.util.Collections;
import java.util.Vector;

public class Race {
    private int rule;
    private Vector<Integer> cards = new Vector<>();
    private final int CARDS = 52;
    private final int CARDS_IN_ONE_COLOR = 13;
    public Race(int rule){
        this.rule = rule;
        for(int i = 0; i < CARDS; i++)
            this.cards.add(i);
        Collections.shuffle(cards);
    }
    public void start(){
        int playerCard, computerCard;
        playerCard = this.cards.elementAt(0);
        computerCard = this.cards.elementAt(1);
        System.out.println("Your hand is " + convertCard(playerCard));
        System.out.println("Computer's hand is " + convertCard(computerCard));
        switch(rule){
            case (RaceKind.BIG):
                if(playerCard % CARDS_IN_ONE_COLOR > computerCard % CARDS_IN_ONE_COLOR){
                    System.out.println(convertCard(playerCard) + " is bigger than " + convertCard(computerCard));
                    System.out.println("You win.");
                }
                else if(playerCard % CARDS_IN_ONE_COLOR < computerCard % CARDS_IN_ONE_COLOR){
                    System.out.println(convertCard(playerCard) + " is smaller than " + convertCard(computerCard));
                    System.out.println("Computer wins.");
                }
                else {
                    if (playerCard / CARDS_IN_ONE_COLOR > computerCard / CARDS_IN_ONE_COLOR) {
                        System.out.println(convertCard(playerCard) + " is bigger than " + convertCard(computerCard));
                        System.out.println("You win.");
                    }
                    else if (playerCard / CARDS_IN_ONE_COLOR < computerCard / CARDS_IN_ONE_COLOR) {
                        System.out.println(convertCard(playerCard) + " is smaller than " + convertCard(computerCard));
                        System.out.println("Computer wins.");
                    }
                    else {
                        System.out.println(convertCard(playerCard) + " is equal to " + convertCard(computerCard));
                        System.out.println("Draw.");
                    }
                }
                break;
            case (RaceKind.SMALL):
                if (playerCard % CARDS_IN_ONE_COLOR < computerCard % CARDS_IN_ONE_COLOR) {
                    System.out.println(convertCard(playerCard) + " is smaller than " + convertCard(computerCard));
                    System.out.println("You win.");
                }
                else if (playerCard % CARDS_IN_ONE_COLOR > computerCard % CARDS_IN_ONE_COLOR) {
                    System.out.println(convertCard(playerCard) + " is bigger than " + convertCard(computerCard));
                    System.out.println("Computer wins.");
                }
                else {
                    if (playerCard / CARDS_IN_ONE_COLOR < computerCard / CARDS_IN_ONE_COLOR) {
                        System.out.println(convertCard(playerCard) + " is smaller than " + convertCard(computerCard));
                        System.out.println("You win.");
                    }
                    else if (playerCard / CARDS_IN_ONE_COLOR > computerCard / CARDS_IN_ONE_COLOR) {
                        System.out.println(convertCard(playerCard) + " is bigger than " + convertCard(computerCard));
                        System.out.println("Computer wins.");
                    }
                    else {
                        System.out.println(convertCard(playerCard) + " is equal to " + convertCard(computerCard));
                        System.out.println("Draw.");
                    }
                }
                break;
        }
    }

    public String convertCard(int cardInNum){
        String card = "";
        switch(cardInNum / CARDS_IN_ONE_COLOR){
            case 0:
                card += "_Club";
                break;
            case 1:
                card += "_Diamond";
                break;
            case 2:
                card += "_Heart";
                break;
            case 3:
                card += "_Spade";
                break;
        }
        switch(cardInNum % CARDS_IN_ONE_COLOR){
            case 0:
                card += "_2";
                break;
            case 1:
                card += "_3";
                break;
            case 2:
                card += "_4";
                break;
            case 3:
                card += "_5";
                break;
            case 4:
                card += "_6";
                break;
            case 5:
                card += "_7";
                break;
            case 6:
                card += "_8";
                break;
            case 7:
                card += "_9";
                break;
            case 8:
                card += "_10";
                break;
            case 9:
                card += "_J";
                break;
            case 10:
                card += "_Q";
                break;
            case 11:
                card += "_K";
                break;
            case 12:
                card += "_A";
                break;
        }
        return card;
    }
}
