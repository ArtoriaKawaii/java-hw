package myjava.homework.part2;

public class RaceKind {
    public final static int BIG = 0x111;
    public final static int SMALL = 0x222;
}
