package myjava.homework;
// You cannot modify anything below
import java.util.Date;

public abstract class ConnectionTemplate {//Template class

	//Hook, a hook is a simple method inside a template class with a default value; this value can be used to change some steps
	private boolean isLoggingEnable = true;

	public ConnectionTemplate(){
		isLoggingEnable = disableLogging();
	}
	
	public final void run(){//won't change
		
		setDBDriver();
		logging("Drivers set ["+new Date()+"]");
		setCredentials();
		logging("Credentails set ["+new Date()+"]");
		connect();
		logging("Conencted");
		prepareStatement();
		logging("Statement prepared ["+new Date()+"]");
		setData();
		logging("Data set ["+new Date()+"]");
		insert();
		logging("Inserted ["+new Date()+"]");
		close();
		logging("Conenctions closed ["+new Date()+"]");
		destroy();
		logging("Object destoryed ["+new Date()+"]");
		
	}
	
	public abstract void setDBDriver();//Template method

	public abstract void setCredentials();//Template method

	public void connect(){
		System.out.println("Setting connection...");
	}
	
	public void prepareStatement(){
		System.out.println("Preparing insert statement...");
	}
	
	public abstract void setData();//Template method
	
	public void insert(){
		System.out.println("Inserting data...");
	}
	
	public void close(){
		System.out.println("Closing connections...");
	}

	public void destroy(){
		System.out.println("Destroying connection objects...");
	}
	
	public boolean disableLogging(){
		return true;
	}
	
	private void logging(String msg){
		if(isLoggingEnable){
			System.out.println("Logging....: "+msg);
		}
	}
}
