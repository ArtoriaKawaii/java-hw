package myjava.homework;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.lang.NumberFormatException;

public class Keypad {
	
	private BufferedReader br;
	
	// initializes 
	public Keypad () {
		br = new BufferedReader(new InputStreamReader(System.in));
	}
	
	/*
	 *  This function may throw some Exception if the user enters non-integer input.
	 *  You must use try...catch to deal with it.
	 */

	public int getInput() {
		/* Fill your code here */
		int input;
		try{
			input = Integer.parseInt(br.readLine());
			if(input < 0)
				return -1;
		}catch(IOException | NumberFormatException exception){
			return -1;
		}
		return input;
	}
	
}
