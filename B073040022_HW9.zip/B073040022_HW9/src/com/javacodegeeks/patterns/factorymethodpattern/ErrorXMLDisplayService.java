package com.javacodegeeks.patterns.factorymethodpattern;

public class ErrorXMLDisplayService extends DisplayService{//實體工廠

	@Override
	public XMLParser getParser() {//Factory Method
		return new ErrorXMLParser();
	}

}
