package myjava.homework.part2;

import java.util.Scanner;

public class BigOrSmall {
    public static void main(String[] args){
        Scanner scan = new Scanner(System.in);
        String option;
        Race race;
        while(true) {
            System.out.println("Which game you want? (You can input \"big\" or \"small\" to play, or input \"exit\" to quit.)");
            option = scan.next();
            switch (option) {
                case "big":
                    race = new Race(RaceKind.BIG);
                    race.start();
                    break;
                case "small":
                    race = new Race(RaceKind.SMALL);
                    race.start();
                    break;
                case "exit":
                    System.out.println("Game Over!!");
                    return;
                default:
                    System.out.println("You have error input. The game is failed!");
            }
        }
    }
}
