package myjava.homework;

import java.io.DataInputStream;
import java.io.IOException;
import java.util.Scanner;

public abstract class ATM {
    public abstract void run();
    public abstract void closeConnection();
    public abstract void processConnection();
    public abstract void sendData(String message) throws IOException;
    public abstract DataInputStream getStreams() throws IOException;
    static Scanner keyboard = new Scanner(System.in);
}
