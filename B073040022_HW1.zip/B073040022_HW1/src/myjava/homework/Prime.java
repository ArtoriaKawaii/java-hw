package myjava.homework;

import java.util.InputMismatchException;
import java.util.Scanner;


public class Prime {
    /* Check whether it's prime number */
    public static boolean isPrime(int num) {
        // Write down your code.
        boolean ans = true;
        if(num == 2);
        else{
            for(int i = 2; i <= java.lang.Math.floor(java.lang.Math.sqrt((double)num)); i++){
                //check if the number is divided by 2~√𝑁. *NOT √(𝑁-1)
                if(num % i == 0){
                    ans = false;
                    break;
                }
            }
        }
        return ans;
    }

    public static void main(String[] args) {
        int option, num, i, count = 0;
        Scanner scan = null;

        while (true) {
            try {
                /* Get standard input object. */
                scan = new Scanner(System.in); //add a scanner object
                /* Print message. */
                System.out.println("1. Check whether it's prime number\n" + "2. Find prime number(2~N)\n" + "3. Leave");
                /* Input an integer. */
                option = scan.nextInt(); //use a method of scanner to read an integer
                switch (option) {
                    case 1:
                        /* Write down your code. */
                        /* Check whether it's prime number */
                        System.out.println("Input the number:");
                        num = scan.nextInt();

                        if(num < 2) {
                            System.out.println("Input error : N must equal greater than 2.");
                            break;
                        }

                        if(isPrime(num))
                            System.out.println(num + " is a prime.");
                        else
                            System.out.println(num + " is not a prime.");

                        break;
                    case 2:
                        /* Write down your code. */
                        /* Find prime number(2~N) */
                        System.out.println("Input the number:");
                        num = scan.nextInt();

                        if(num < 2) {
                            System.out.println("Input error : N must equal greater than 2.");
                            break;
                        }

                        System.out.printf("Show the prime numbers(2 ~ %d)\n", num);

                        for(i = 2, count = 0; i <= num; i++){
                            if(isPrime(i)) {
                                System.out.printf("%d\t\t", i);
                                count++;
                                if(count % 10 == 0)
                                    System.out.println();
                            }
                        }
                        if(count % 10 != 0)
                            System.out.println();
                        break;
                    case 3:
                        /* Write down your code. */
                        /* End the process */
                        System.out.println("Bye!!!");
                        return;
                    default:
                        System.out.println("Input error : incorrect option");
                        break;
                }
            } catch (InputMismatchException e) {
                //try & catch to avoid improper value being scan
                System.out.println("Input error : ONLY Integers.");
            }
        }
    }
}
