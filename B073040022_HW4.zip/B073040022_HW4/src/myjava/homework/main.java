package myjava.homework;

import java.util.Scanner;
import java.util.StringTokenizer;

public class main {
    public static void main(String[] args){
        Scanner keyboard = new Scanner(System.in);
        while(true) {
            System.out.println("Choose your four star game type(1.Combination 2.Permutation 3.Exit)");
            String option = keyboard.nextLine();
            if(new StringTokenizer(option).countTokens() >= 2 || option.length() >= 2 || !Character.isDigit(option.charAt(0))){
                System.out.println("Wrong input, try again.");//Check input
                continue;
            }
            switch(Integer.parseInt(option)){
                case 1: {
                    Combination game = new Combination();
                    game.generateWinNums();
                    System.out.print("Win numbers : ");
                    for(Integer num : game.getWinNums())
                        System.out.print(num + " ");
                    System.out.println();
                    game.generateUserNums();
                    if(game.flag == -1)
                        break;
                    else {
                        game.checkOfWin();
                        break;
                    }
                }
                case 2: {
                    Permutation game = new Permutation();
                    game.generateWinNums();
                    System.out.print("Win numbers : ");
                    for(Integer num : game.getWinNums())
                        System.out.print(num + " ");
                    System.out.println();
                    game.generateUserNums();
                    if(game.flag == -1)
                        break;
                    else {
                        game.checkOfWin();
                        break;
                    }
                }
                case 3:
                    return;
                default:
                    System.out.println("Wrong input, try again.");
            }
        }
    }
}
