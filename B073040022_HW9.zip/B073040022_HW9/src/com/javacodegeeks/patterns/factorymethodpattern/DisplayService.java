package com.javacodegeeks.patterns.factorymethodpattern;

public abstract class DisplayService {//虛擬工廠
	
	public void display(){
		XMLParser parser = getParser();//Factory Method
		String msg = parser.parse();//XXX XML Message
		System.out.println(msg);
	}
	
	protected abstract XMLParser getParser();//Factory Method

}
