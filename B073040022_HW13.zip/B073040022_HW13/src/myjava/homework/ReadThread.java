package myjava.homework;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.util.concurrent.CountDownLatch;

/*read file and count specified word*/
public class ReadThread extends Thread{
    //定義位元組陣列的長度
    private final int BUFF_LEN = 256;

    //定義讀取的起始點
    private long start;

    //定義讀取的結束點
    private long end;

    //將讀取到的位元組輸出到raf中  RandomAccessFile可以理解為檔案流，即檔案中提取指定的一部分的包裝物件
    private RandomAccessFile raf;

    //執行緒中需要指定的關鍵字
    private String keywords;

    //此執行緒讀到關鍵字的次數
    private int curCount = 0;

    //A synchronization aid that allows one or more threads to wait until
    // a set of operations being performed in other threads completes
    private CountDownLatch doneSignal;
    public ReadThread(long start, long end, RandomAccessFile raf,String keywords,CountDownLatch doneSignal){
        this.start = start;
        this.end = end;
        this.raf  = raf;
        this.keywords = keywords;
        this.doneSignal = doneSignal;
    }

    @Override
    public void run() {
        try {
            raf.seek(start);

            //calculate the size of the file
            long contentLen = end - start;

            //calculate how many times to read the file
            long times = contentLen / BUFF_LEN+1;

            //System.out.println(this.toString() + " 需要讀的次數："+times);//TEST
            byte[] buff = new byte[BUFF_LEN];
            int hasRead = 0;
            String result = null;
            for (int i = 0; i < times; i++) {
                //之前seek()指定了起始位置，這裡讀入指定位元組組長度的內容，read方法返回的是下一個開始讀的position
                hasRead = raf.read(buff);

                //如果讀取的位元組數小於0，則退出迴圈！ （到了位元組陣列的末尾）
                if (hasRead < 0) {
                    break;
                }

                result = new String(buff,"UTF-8");
                //System.out.println(result);//TEST
                int count = this.getCountByKeywords(result, keywords);
                if(count > 0){
                    this.curCount += count;
                }
            }

            KeyWordCount kc = KeyWordCount.getCountObject();

            kc.addCount(this.curCount);

            doneSignal.countDown();//current thread finished! noted by latch object!
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }

    public int getCountByKeywords(String statement,String key){
        return statement.split(key).length-1;
    }

    //un-used accessor / mutator
    public long getStart() {
        return start;
    }

    public void setStart(long start) {
        this.start = start;
    }

    public long getEnd() {
        return end;
    }

    public void setEnd(long end) {
        this.end = end;
    }

    public RandomAccessFile getRaf() {
        return raf;
    }

    public void setRaf(RandomAccessFile raf) {
        this.raf = raf;
    }

    public int getCurCount() {
        return curCount;
    }

    public void setCurCount(int curCount) {
        this.curCount = curCount;
    }

    public CountDownLatch getDoneSignal() {
        return doneSignal;
    }

    public void setDoneSignal(CountDownLatch doneSignal) {
        this.doneSignal = doneSignal;
    }
}
