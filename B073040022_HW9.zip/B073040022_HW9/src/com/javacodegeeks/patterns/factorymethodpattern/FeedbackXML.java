package com.javacodegeeks.patterns.factorymethodpattern;

public class FeedbackXML implements XMLParser{//實體物件

	@Override
	public String parse() {
		System.out.println("Parsing feedback XML...");
		return "Feedback XML Message";
	}

}

