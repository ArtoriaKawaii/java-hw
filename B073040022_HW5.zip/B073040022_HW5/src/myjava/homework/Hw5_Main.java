package myjava.homework;

public class Hw5_Main {

	public static void main(String[] args) {
		
		ATM theATM = new ATM();
		theATM.run();

	}

}
