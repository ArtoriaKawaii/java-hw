package myjava.homework;

public class Screen {
	public Screen(){

	}
	//display a message without a carriage return
	public void displayMessage (String message) {
        System.out.print(message);
	}
	
	//display a message with a carriage return(\n)
	public void displayMessageLine (String message) {
		System.out.println(message);
	}
	
}
