package myjava.homework;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.sql.*;

public class Server extends ATM implements Runnable{

    /*Socket*/
    private ServerSocket serverSocket;//Server端的Socket，接收Client端的連線
    private Socket socket;//Server和Client之間的連線通道

    /*JDBC*/
    private Connection connection = null;   //manages connection
    private Statement statement = null;     //query statement

    private Server(int port){
        try{
            serverSocket = new ServerSocket(port);//建立Server端的Socket，並且設定Port
        }catch (IOException e) {
            System.out.println(e.getMessage());//出現例外(無法建立連線時)時，捕捉並顯示例外訊息
        }
    }

    @Override
    public void run() {
        processConnection();
        processConnectionToDB();
        while(true){
            try {
                int option = Integer.parseInt(getStreams().readUTF());
                switch(option){
                    case 1:{
                        System.out.println("Signing in...");
                        String account = getStreams().readUTF();
                        String password = getStreams().readUTF();
                        if(searchInUser(account, password)){
                            sendData("Sign in success");
                            System.out.println("Sign in success");
                            option = Integer.parseInt(getStreams().readUTF());
                            switch (option){
                                case 1:{
                                    System.out.println("Deposit...");
                                    int currentMoney = 0, depositMoney = Integer.parseInt(getStreams().readUTF());
                                    ResultSet resultSet = statement.executeQuery("SELECT * FROM money");//matching account with money table
                                    while(resultSet.next()) {
                                        if (account.equals(resultSet.getString(1))) {
                                            currentMoney = Integer.parseInt(resultSet.getString(2));//get current balance
                                            break;
                                        }
                                    }
                                    statement.executeUpdate("UPDATE money SET balance = '" + (currentMoney + depositMoney) + "' WHERE user = '" + account + "'");
                                    resultSet = statement.executeQuery("SELECT * FROM money");//matching account with money table
                                    while(resultSet.next()) {
                                        if (account.equals(resultSet.getString(1))) {
                                            sendData(resultSet.getString(2));
                                            break;
                                        }
                                    }
                                    System.out.println("Deposit success");
                                    resultSet.close();
                                    break;
                                }
                                case 2:{
                                    System.out.println("Withdraw...");
                                    int currentMoney = 0, withdrawMoney = Integer.parseInt(getStreams().readUTF());
                                    ResultSet resultSet = statement.executeQuery("SELECT * FROM money");//matching account with money table
                                    while(resultSet.next()) {
                                        if (account.equals(resultSet.getString(1))){
                                            currentMoney = Integer.parseInt(resultSet.getString(2));//get current balance
                                            break;
                                        }
                                    }
                                    if(currentMoney < withdrawMoney){
                                        sendData("-1");//withdraw fail
                                        System.out.println("Withdraw fail");
                                    }
                                    else {
                                        statement.executeUpdate("UPDATE money SET balance = '" + (currentMoney - withdrawMoney) + "' WHERE user = '" + account + "'");//update balance
                                        resultSet = statement.executeQuery("SELECT * FROM money");//matching account with money table
                                        while (resultSet.next()) {
                                            if (account.equals(resultSet.getString(1))) {
                                                sendData(resultSet.getString(2));
                                                break;
                                            }
                                        }
                                        System.out.println("Withdraw success");
                                    }
                                    resultSet.close();
                                    break;
                                }
                                case 3:{
                                    System.out.println("Balance...");
                                    ResultSet resultSet = statement.executeQuery("SELECT * FROM money");//matching account with money table
                                    while(resultSet.next()) {
                                        if (account.equals(resultSet.getString(1))) {
                                            sendData(resultSet.getString(2));
                                            break;
                                        }
                                    }
                                    resultSet.close();
                                    break;
                                }
                                case 4:{
                                    System.out.println("Log out...");
                                    break;
                                }
                            }
                        }
                        else {
                            sendData("-1");//sign in fail
                            System.out.println("Sign in fail");
                        }
                        break;
                    }
                    case 2:{
                        System.out.println("Creating account...");
                        String account = getStreams().readUTF();
                        String password = getStreams().readUTF();
                        if(searchInUser(account, password)){
                            sendData("Account already exist");
                            System.out.println("Create fail");
                        }
                        else{
                            sendData("-1");//create account
                            statement.executeUpdate("INSERT INTO user (id, password) VALUES ('" + account + "', '" + password + "')");
                            statement.executeUpdate("INSERT INTO money (user, balance) VALUES ('" + account + "', '0')");
                            System.out.println("Create success");
                        }
                        break;
                    }
                    case 3:{
                        System.out.println("End Server...");
                        closeConnection();
                        return;
                    }
                }
            }catch (IOException e){
                System.out.println("Data stream error");
            }catch (NumberFormatException e){
                System.out.println("Input error");
            }catch (SQLException e){
                System.out.println("SQL error");
            }
        }
    }
    public void processConnection(){//connect to Client
        try {
            System.out.println("Connecting......");
            socket = serverSocket.accept();//等待Client端的連線，若未連線則程式一直停在這裡
            System.out.println("Connecting Success");

            serverSocket.close();//一旦連線建立成功，且不需要再接收其他連線，則可關閉ServerSocket
        }catch (IOException e){
            System.out.println("Connection fail");//出現例外(無法建立連線時)時，捕捉並顯示例外訊息
        }
    }
    private void processConnectionToDB(){//connect to database java_hw10
        try{
            //establish connection to database
            connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/java_hw10?serverTimezone=UTC", "root", "");

            //create Statement for querying database
            statement = connection.createStatement();
        }catch(SQLException sqlException) {
            System.out.println("Error occur making database connection");
        }
    }
    public void closeConnection(){//closing socket & database connection
        try{
            socket.close();
            statement.close();
            connection.close();
        }catch(IOException e){
            System.out.println("Error occur closing socket connection");
        }catch (SQLException e){
            System.out.println("Error occur closing database connection");
        }
    }
    public void sendData(String message) throws IOException{//sending data(especially String) to Client
        DataOutputStream toClient = new DataOutputStream(socket.getOutputStream());
        toClient.writeUTF(message);
    }
    public DataInputStream getStreams() throws IOException{//get data streams from Client
        return new DataInputStream(socket.getInputStream());
    }
    private boolean searchInUser(String account, String password) throws SQLException {//matching account with user table
        ResultSet resultSet = statement.executeQuery("SELECT * FROM user");
        while (resultSet.next()) {
            if (account.equals(resultSet.getObject(1)) && password.equals(resultSet.getObject(2))) {
                resultSet.close();
                return true;
            }
        }
        return false;
    }
    public static void main(String[] args){
        new Thread(new Server(12345)).start();
    }
}
