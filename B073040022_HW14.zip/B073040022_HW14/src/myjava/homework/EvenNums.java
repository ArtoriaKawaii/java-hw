package myjava.homework;
import java.io.FileWriter;
import java.io.IOException;
import java.util.stream.DoubleStream;
import java.util.stream.IntStream;
import static java.lang.StrictMath.sqrt;

public class EvenNums implements Runnable{
    private int[] evenNums;
    private FileWriter fw;
    public EvenNums(int[] evenNums,FileWriter fw) {
        this.evenNums=evenNums;
        this.fw=fw;
    }

    @Override
    public void run() {
        synchronized(fw){
            try {
                fw.write("Even number: " + IntStream.of(evenNums).filter(value -> value % 2 == 0).count() + "\n");//Lambda
            }
            catch (IOException e){
                System.out.println("Cannot write to file.");
            }
        }
        try {
            Thread.sleep(200);
        } catch (Exception ignored) {

        }
        synchronized(fw){
            try {
                fw.write("Even number average: " + IntStream.of(evenNums).filter(value -> value % 2 == 0).average().getAsDouble() + "\n");//Lambda
            }
            catch (IOException e){
                System.out.println("Cannot write to file.");
            }
        }
        try {
            Thread.sleep(200);
        } catch (Exception ignored) {

        }
        synchronized(fw){
            try {
                fw.write("Even number max: " + IntStream.of(evenNums).filter(value -> value % 2 == 0).max().getAsInt() + "\n");//Lambda
            }
            catch (IOException e){
                System.out.println("Cannot write to file.");
            }
        }
        try {
            Thread.sleep(250);
        } catch (Exception ignored) {

        }
        synchronized(fw){
            try {
                fw.write("Even number min: " + IntStream.of(evenNums).filter(value -> value % 2 == 0).min().getAsInt() + "\n");//Lambda
            }
            catch (IOException e){
                System.out.println("Cannot write to file.");
            }
        }
        try {
            Thread.sleep(300);
        } catch (Exception ignored) {

        }
        synchronized(fw){
            try {
                double avg_sqr=(IntStream.of(evenNums).filter(value -> value % 2 == 0).average().getAsDouble()) * (IntStream.of(evenNums).filter(value -> value % 2 == 0).average().getAsDouble());//Lambda//β^2
                double sum = 0;
                double[] doubles = new double[evenNums.length];
                for(int i=0; i<evenNums.length; i++) {
                    doubles[i] = evenNums[i];
                }
                sum = DoubleStream.of(doubles).filter(value -> value % 2 == 0).reduce(0.0,(x, y) -> x + (y * y - avg_sqr));//Lambda//Σ(α2−β2)
                sum = sqrt(sum);//√Σ(α2−β2)
                fw.write("Even number formula:" + sum + "\n");
            }
            catch (IOException e){
                System.out.println("Cannot write to file.");
            }
        }
    }
}
