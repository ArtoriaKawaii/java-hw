// Represents a withdrawal ATM transaction
package myjava.homework;

public class Withdrawal extends Transaction {
    public Withdrawal(int accountNumber){
        super(accountNumber);
    }
    public void execute() {
        if(ATM.bankDatabase.getTotalBalance(getAccountNumber()) == 0) {
            output.displayMessageLine("Sorry you have nothing left in your account.\n");
            return;
        }
        int withdraw;
        while(true) {
            output.displayMessage("How much do you want to withdraw : ");
            withdraw = input.getInput();
            if (withdraw != -1)
                break;
            output.displayMessageLine("Input error.");
        }
        if(withdraw <= ATM.bankDatabase.getTotalBalance(getAccountNumber())) {
            ATM.bankDatabase.setTotalBalance(getAccountNumber(), ATM.bankDatabase.getTotalBalance(getAccountNumber()) - withdraw);
            output.displayMessageLine("Transaction success.\n");
        }
        else
            output.displayMessageLine("Transaction error. You don't have that much money to withdraw.\n");
    }
}
