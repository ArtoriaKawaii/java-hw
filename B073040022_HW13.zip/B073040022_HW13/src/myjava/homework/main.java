package myjava.homework;

import java.io.File;
import java.io.RandomAccessFile;
import java.util.concurrent.CountDownLatch;

public class main {
    public static void main(String[] args) {
        // TODO Auto-generated method stub
        final int DOWN_THREAD_NUM = 5;//起5個執行緒去讀取指定檔案

        final String OUT_FILE_NAME = "E:\\Data\\大學\\大一下\\JAVA\\HW13\\B073040022_HW13\\src\\myjava\\homework\\20190530.txt";
        final String keywords = "boy";

        //jdk1.5執行緒輔助類，讓主執行緒等待所有子執行緒執行完畢後使用的類，
        //另外一個解決方案：自己寫定時器，個人建議用這個類
        CountDownLatch doneSignal = new CountDownLatch(DOWN_THREAD_NUM);

        RandomAccessFile[] outArr = new RandomAccessFile[DOWN_THREAD_NUM];

        try{
            long length = new File(OUT_FILE_NAME).length();
            //System.out.println("檔案總長度："+length+"位元組");//TEST

            //每執行緒應該讀取的位元組數
            long numPerThread = length / DOWN_THREAD_NUM;

            //System.out.println("每個執行緒讀取的位元組數："+numPerThread+"位元組");//TEST
            //整個檔案整除後剩下的餘數
            long left = length % DOWN_THREAD_NUM;
            for (int i = 0; i < DOWN_THREAD_NUM; i++) {
                //為每個執行緒開啟一個輸入流、一個RandomAccessFile物件，

                //讓每個執行緒分別負責讀取檔案的不同部分
                outArr[i] = new RandomAccessFile(OUT_FILE_NAME, "rw");

                if (i == DOWN_THREAD_NUM - 1) {
                    //最後一個執行緒讀取指定numPerThread+left個位元組
                    new ReadThread(i * numPerThread, (i + 1) * numPerThread
                            + left, outArr[i],keywords,doneSignal).start();
                } else {
                    //每個執行緒負責讀取一定的numPerThread個位元組
                    new ReadThread(i * numPerThread, (i + 1) * numPerThread,
                            outArr[i],keywords,doneSignal).start();
                }
            }
        }catch(Exception e){
            e.printStackTrace();
        }
        try {
            doneSignal.await();
        } catch (InterruptedException e) { //判斷所有做ReadThread是否全部執行完。
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        KeyWordCount k = KeyWordCount.getCountObject();
        System.out.println("-------------------------");
        System.out.println("找到關鍵字的總個數："+k.getCount());
    }
}
