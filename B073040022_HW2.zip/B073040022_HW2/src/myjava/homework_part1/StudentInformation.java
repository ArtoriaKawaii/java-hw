package myjava.homework_part1;

public class StudentInformation {
    private String id;
    private String name;
    private int score;

    public StudentInformation(){
//        this.id = null; can't assign null to an object
//        this.name = null; can't assign null to an object
        this.score = 0;
    }

    public void setID(String id){
        this.id = id;
    }

    public void setName(String name){
        this.name = name;
    }

    public void setScore(int score){
        this.score = score;
    }

    public String getID(){
        return id;
    }

    public String getName(){
        return name;
    }

    public int getScore(){
        return score;
    }

    public void setData(String id, String name, int score){
        setID(id);
        setName(name);
        setScore(score);
    }

    public void show_data(){
        System.out.println("Student id :" + this.id);
        System.out.println("Student name :" + this.name);
        if (this.score >= 60)
            System.out.print("Student " + this.name +" pass this project.\n\n");
        else
            System.out.print("Student " + this.name +" fail this project.\n\n");
    }
}