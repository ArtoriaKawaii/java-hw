package myjava.homework_part2;

import java.util.Scanner;

public class Controller {
    public static void main(String[] args){
        int option;
        ItemList itemList = new ItemList();
        Scanner scan = new Scanner(System.in);
        while(true){
            while(true) {
                System.out.println("Type 1 : add item to list");
                System.out.println("Type 2 : remove item from list");
                System.out.println("Type 3 : show the list");
                System.out.println("Enter other NUMBER to exit.");
                if (scan.hasNextInt()) {
                    option = scan.nextInt();
                    break;
                }
                else {
                    System.out.println("Invalid type. Enter type again.");
                    scan.nextLine();
                }
            }
            switch(option){
                case 1 :
                    System.out.print("Add item name :");
                    itemList.addItem(scan.next());
                    System.out.println();
                    break;
                case 2 :
                    System.out.print("Remove item name :");
                    itemList.remove(scan.next());
                    System.out.println();
                    break;
                case 3 :
                    System.out.println("Show the list");
                    itemList.printList();
                    break;
                default :
                    return ;
            }
        }
    }
}
