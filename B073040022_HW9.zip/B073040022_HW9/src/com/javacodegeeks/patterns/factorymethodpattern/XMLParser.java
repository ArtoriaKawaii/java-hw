package com.javacodegeeks.patterns.factorymethodpattern;

public interface XMLParser {//standard class
	
	public String parse();

}
