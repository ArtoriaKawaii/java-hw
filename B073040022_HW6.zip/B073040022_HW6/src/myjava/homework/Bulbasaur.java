package myjava.homework;

import java.util.InputMismatchException;

public class Bulbasaur extends Pokemon {
    public Bulbasaur(int hp, int atk, int unique){
        super(hp, atk, unique);
    }
    public int attack_skill() {
        return (int)(Math.random() * 10) + getAtk() * 4;
    }
    public int defense_skill() {
        return (int)(Math.random() * 10) + getAtk() * 4;
    }

    public int buff_skill() {
        return (int)(Math.random() * 10) + getAtk() * 2;
    }

    public int action(){
        int action, wildPokemon_HP, wildPokemonOrigin_HP, wildPokemon_ATK;
        System.out.println("[Wild pokemon appeared!]");
        wildPokemon_HP = (int) (Math.random() * 150 + 150);
        wildPokemonOrigin_HP = wildPokemon_HP;
        wildPokemon_ATK = (int) (Math.random() * 5 + 30);
        while(true){
            System.out.println("----Pokemon----\t----Wild Pokemon----");
            System.out.format("  HP:%3d\t\t  HP:%3d\n", getHp(), wildPokemon_HP);
            System.out.format("  ATK:%2d\t\t  ATK:%2d\n", getAtk(), wildPokemon_ATK);
            System.out.format("  LS:%d\n", getUnique());
            System.out.println("---------------\t--------------------");
            if(getHp() == 0){
                System.out.println("You dead.");
                return 0;
            }
            if(winFlag){
                System.out.println("You win.");
                return 0;
            }
            System.out.println("(1)Razor leaf (2)Light screen (3)Synthesis (4)Catch");
            System.out.print("Action (By default (1)) : ");
            try{
                action = input.nextInt();
            }catch (InputMismatchException e){
                input.nextLine();
                action = 1;
            }
            switch(action){
                case 1:
                default: {
                    int damage = attack_skill();
                    System.out.println("[Razor leaf] : " + damage + " damage.");
                    wildPokemon_HP -= damage;
                    if (wildPokemon_HP <= 0) {
                        wildPokemon_HP = 0;
                        winFlag = true;
                        break;
                    }
                    getDamage(wildPokemon_ATK);
                    break;
                }
                case 2: {
                    int shield = defense_skill();
                    if (getUnique() == 0)//Shield cannot be superimposed
                        System.out.println("[Light screen] : Shield + " + shield + " points.");
                    else
                        System.out.println("[Light screen] : Shield recharge to " + shield + " points.");
                    setUnique(shield);
                    getDamage(wildPokemon_ATK);
                    break;
                }
                case 3: {
                    int recovery = buff_skill();
                    System.out.println("[Synthesis] : HP + " + recovery + " points.");
                    if (getHp() + recovery > 40)//Max health == 40
                        setHp(40);
                    else
                        setHp(getHp() + recovery);
                    getDamage(wildPokemon_ATK);
                    break;
                }
                case 4:
                    System.out.println("[Catch] : Throw the Poke ball.");
                    if ((double)(wildPokemonOrigin_HP - wildPokemon_HP) / wildPokemonOrigin_HP >= Math.random()) {
                        System.out.println("---------------\t--------------------");
                        System.out.println("You caught the wild pokemon.");
                        return 0;
                    } else {
                        System.out.println("You DID NOT catch the wild pokemon.");
                        getDamage(wildPokemon_ATK);
                    }
            }
        }
    }
    public void getDamage(int wildPokemon_ATK) {
        int wildPokemon_damage = (int) (Math.random() * 10 + wildPokemon_ATK);
        System.out.println("[Wild pokemon] : " + wildPokemon_damage + " damage.");
        if(getUnique() >= wildPokemon_damage){
            System.out.println("[Light Shield] : Shield - " + wildPokemon_damage + " damage.");
            setUnique(getUnique() - wildPokemon_damage);
        }
        else if(getUnique() < wildPokemon_damage && getUnique() != 0){
            System.out.println("[Light Shield] : Shield - " + getUnique() + " damage.");
            wildPokemon_damage -= getUnique();
            setUnique(0);
            System.out.println("[Bulbasaur] : HP - " + wildPokemon_damage + " points");
            if(getHp() - wildPokemon_damage > 0)
                setHp(getHp() - wildPokemon_damage);
            else
                setHp(0);
        }
        else{
            System.out.println("[Light Shield] : Shield - 0 damage.");
            System.out.println("[Bulbasaur] : HP - " + wildPokemon_damage + " points");
            if(getHp() - wildPokemon_damage > 0)
                setHp(getHp() - wildPokemon_damage);
            else
                setHp(0);
        }
    }
}
