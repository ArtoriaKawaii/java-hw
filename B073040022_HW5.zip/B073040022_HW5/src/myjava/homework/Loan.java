// Represents a withdrawal ATM transaction
package myjava.homework;

public class Loan extends Transaction {
    public Loan(int accountNumber){
        super(accountNumber);
    }
    public void execute(){
        int loanLimit = 0, loan;
        output.displayMessageLine("Your debt : " + ATM.bankDatabase.getDebt(getAccountNumber()));
        switch (ATM.bankDatabase.getCreditLevel(getAccountNumber())){
            case 'A':
                loanLimit = 11000 - ATM.bankDatabase.getDebt(getAccountNumber());
                break;
            case 'B':
                loanLimit = 9000 - ATM.bankDatabase.getDebt(getAccountNumber());
                break;
            case 'C':
                loanLimit = 7000 - ATM.bankDatabase.getDebt(getAccountNumber());
                break;
            case 'D':
                loanLimit = 5000 - ATM.bankDatabase.getDebt(getAccountNumber());
                break;
        }
        if(loanLimit == 0){
            output.displayMessageLine("Sorry, you can't loan any money.\n");
            return;
        }
        while(true) {
            output.displayMessage("Your loan limit is " + loanLimit + ", how much do you want to loan : ");
            loan = input.getInput();
            if(loan != -1)
                break;
            output.displayMessageLine("Input error.");
        }
        if(loan <= loanLimit){
            ATM.bankDatabase.setDebt(getAccountNumber(), ATM.bankDatabase.getDebt(getAccountNumber()) + loan);
            ATM.bankDatabase.setTotalBalance(getAccountNumber(), ATM.bankDatabase.getTotalBalance(getAccountNumber()) + loan);
            output.displayMessageLine("Transaction success.\n");
        }
        else{
            output.displayMessageLine("Transaction error, you don't have enough loan limit.\n");
        }
    }
}
