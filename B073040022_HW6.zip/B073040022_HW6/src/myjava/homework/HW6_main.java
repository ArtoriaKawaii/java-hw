package myjava.homework;

import java.util.InputMismatchException;
import java.util.Scanner;

public class HW6_main {

    public static void main(String[] args) {
        int option;
        Pokemon pokemon;
        Scanner input = new Scanner(System.in);
        System.out.println("(1) Pikachu (2) Bulbasaur (3) Charizard");
        System.out.print("Choose your pokemon (By default (1)) : ");
        try {
            option = input.nextInt();
        } catch (InputMismatchException e) {
            input.nextLine();//clear buffer
            option = 1;
        }
        switch (option) {
            case 1:
            default:
                pokemon = new Pikachu(80, 40, 20);
                break;
            case 2:
                pokemon = new Bulbasaur(40, 20, 0);
                break;
            case 3:
                pokemon = new Charizard(200, 60, 30);
                break;
        }
        pokemon.action();
    }
}

