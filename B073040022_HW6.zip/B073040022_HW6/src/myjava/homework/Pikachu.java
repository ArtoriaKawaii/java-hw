package myjava.homework;

import java.util.InputMismatchException;

public class Pikachu extends Pokemon {
    public Pikachu(int hp, int atk, int unique){
        super(hp, atk, unique);
    }
    public int attack_skill() {
        return (int)(Math.random() * 10) + getAtk();
    }
    public int defense_skill() {
        return getUnique() * 2;
    }
    public int buff_skill() {
        return getAtk() * 2;
    }
    public int action() {
        int action, wildPokemon_HP, wildPokemonOrigin_HP, wildPokemon_ATK;
        System.out.println("[Wild pokemon appeared!]");
        wildPokemon_HP = (int) (Math.random() * 150 + 150);
        wildPokemonOrigin_HP = wildPokemon_HP;
        wildPokemon_ATK = (int) (Math.random() * 5 + 30);
        while(true){
            System.out.println("----Pokemon----\t----Wild Pokemon----");
            System.out.format("  HP:%3d\t\t  HP:%3d\n", getHp(), wildPokemon_HP);
            System.out.format("  ATK:%2d\t\t  ATK:%2d\n", getAtk(), wildPokemon_ATK);
            System.out.format("  EVA:%d\n", getUnique());
            System.out.println("---------------\t--------------------");
            if(getHp() == 0){
                System.out.println("You dead.");
                return 0;
            }
            if(winFlag){
                System.out.println("You win.");
                return 0;
            }
            System.out.println("(1)Thunder shock (2)Double team (3)Thunder (4)Catch");
            System.out.print("Action (By default (1)) : ");
            try{
                action = input.nextInt();
            }catch (InputMismatchException e){
                input.nextLine();
                action = 1;
            }
            switch(action){
                case 1:
                default:{
                    int damage = attack_skill();
                    System.out.println("[Thunder shock] : " + damage + " damage.");
                    wildPokemon_HP -= damage;
                    if(wildPokemon_HP <= 0){
                        wildPokemon_HP = 0;
                        winFlag = true;
                        break;
                    }
                    getDamage(wildPokemon_ATK);
                    break;
                }
                case 2:
                    System.out.println("[Double team] : EVA + " + getUnique() + " points.");
                    setUnique(defense_skill());
                    if(getUnique() > 100)//Max evasion == 100(%)
                        setUnique(100);
                    getDamage(wildPokemon_ATK);
                    break;
                case 3:
                    System.out.println("[Thunder] : ATK + " + getAtk() + " damage.");
                    setAtk(buff_skill());
                    getDamage(wildPokemon_ATK);
                    break;
                case 4:
                    System.out.println("[Catch] : Throw the Poke ball.");
                    if ((double)(wildPokemonOrigin_HP - wildPokemon_HP) / wildPokemonOrigin_HP >= Math.random()) {
                        System.out.println("---------------\t--------------------");
                        System.out.println("You caught the wild pokemon.");
                        return 0;
                    } else {
                        System.out.println("You DID NOT catch the wild pokemon.");
                        getDamage(wildPokemon_ATK);
                    }
            }
        }
    }

    public void getDamage(int wildPokemon_ATK) {
        int wildPokemon_damage = (int) (Math.random() * 10 + wildPokemon_ATK);
        System.out.println("[Wild pokemon] : " + wildPokemon_damage + " damage.");
        if((getUnique() / 100.0) >= Math.random())
            System.out.println("Evasion succeed.");
        else{
            System.out.println("[Pikachu] : HP - " + wildPokemon_damage + "points.");
            if(getHp() - wildPokemon_damage > 0)
                setHp(getHp() - wildPokemon_damage);
            else
                setHp(0);
        }
    }
}
