package PokemonData;

import java.util.Random;

public class Pokemon {
    protected String Name;
    protected int HP = 10;
    protected int ATK = 2;
    protected int DEF = 2;
    protected int Height = 50;//centimeter(least)
    protected int Weight = 1000;//gram(least)
    protected Random rand = new Random();
    protected int CatchRate = 30 + rand.nextInt(60 + 1);//30%~90%
    public Pokemon(){
    }
    public String toString(){//print pokemon status
        System.out.println("Pokemon : " + Name);
        System.out.printf("HP : %3d\tATK : %3d\tDEF : %3d\tCP : %4d\n", HP, ATK, DEF, CombatPower());
        System.out.print("Height : " + Height / 100.0 + " m" + "\t\tWeight : " + Weight / 1000.0 + " kg");
        return "\n";
    }
    public boolean Catch(int probability){//probability+(0%, 5%, 10%)
        int randNum = rand.nextInt(100) + 1;//1~100
        return (CatchRate + probability >= randNum);
    }
    public int CombatPower(){
        return (int)(HP * 2 + ATK * 1.5 + DEF * 1.5);
    }
    public boolean Runaway(int round){
        int randNum = rand.nextInt(100) + 1;//1~100
        return (5 + round * 5 >= randNum);
    }
}
