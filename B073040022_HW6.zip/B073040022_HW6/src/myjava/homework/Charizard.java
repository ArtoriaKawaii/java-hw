package myjava.homework;

import java.util.InputMismatchException;

public class Charizard extends Pokemon {
    public Charizard(int hp, int atk, int unique){
        super(hp, atk, unique);
    }
    public int attack_skill() {
        if(getUnique() / 100.0 >= Math.random())
            return (int)(Math.random() * 10 + getAtk()) * 2;
        else
            return (int)(Math.random() * 10 + getAtk());
    }

    public int defense_skill() {
        return 0;
    }

    public int buff_skill() {
        if(getUnique() + 25 > 100)
            setUnique(100);
        else
            setUnique(getUnique() + 25);
        return getUnique();
    }

    public int action() {
        int action, wildPokemon_HP, wildPokemonOrigin_HP, wildPokemon_ATK;
        System.out.println("[Wild pokemon appeared!]");
        wildPokemon_HP = (int) (Math.random() * 150 + 150);
        wildPokemonOrigin_HP = wildPokemon_HP;
        wildPokemon_ATK = (int) (Math.random() * 5 + 30);
        while(true){
            System.out.println("----Pokemon----\t----Wild Pokemon----");
            System.out.format("  HP:%3d\t\t  HP:%3d\n", getHp(), wildPokemon_HP);
            System.out.format("  ATK:%2d\t\t  ATK:%2d\n", getAtk(), wildPokemon_ATK);
            System.out.format("  CRI:%d\n", getUnique());
            System.out.println("---------------\t--------------------");
            if(getHp() == 0){
                System.out.println("You dead.");
                return 0;
            }
            if(winFlag){
                System.out.println("You win.");
                return 0;
            }
            System.out.println("(1)Flame thrower (2)Parry (3)Work up (4)Catch");
            System.out.print("Action (By default (1)) : ");
            try{
                action = input.nextInt();
            }catch (InputMismatchException e){
                input.nextLine();
                action = 1;
            }
            switch(action){
                case 1:
                default: {
                    int damage = attack_skill();
                    System.out.println("[Flame thrower] : " + damage + " damage.");
                    wildPokemon_HP -= damage;
                    if(wildPokemon_HP <= 0){
                        wildPokemon_HP = 0;
                        winFlag = true;
                        break;
                    }
                    getDamage(wildPokemon_ATK);
                    break;
                }
                case 2: {
                    System.out.println("[Parry] : return next damage.");
                    int wildPokemon_damage = (int) (Math.random() * 10 + wildPokemon_ATK);
                    System.out.println("[Wild pokemon] : " + wildPokemon_damage + " damage.");
                    System.out.println("[Charizard] : HP - " + wildPokemon_damage + "points.");
                    if(getHp() - wildPokemon_damage > 0) {
                        setHp(getHp() - wildPokemon_damage);
                        wildPokemon_HP -= wildPokemon_damage;
                        if(wildPokemon_HP <= 0){
                            wildPokemon_HP = 0;
                            winFlag = true;
                        }
                    }
                    else
                        setHp(0);
                    break;
                }
                case 3:
                    System.out.println("[Work up] : CRI " + buff_skill() + " %.");
                    getDamage(wildPokemon_ATK);
                    break;
                case 4:
                    System.out.println("[Catch] : Throw the Poke ball.");
                    if ((double)(wildPokemonOrigin_HP - wildPokemon_HP) / wildPokemonOrigin_HP >= Math.random()) {
                        System.out.println("---------------\t--------------------");
                        System.out.println("You caught the wild pokemon.");
                        return 0;
                    } else {
                        System.out.println("You DID NOT catch the wild pokemon.");
                        getDamage(wildPokemon_ATK);
                    }
            }
        }
    }
    public void getDamage(int wildPokemon_ATK){
        int wildPokemon_damage = (int) (Math.random() * 10 + wildPokemon_ATK);
        System.out.println("[Wild pokemon] : " + wildPokemon_damage + " damage.");
        System.out.println("[Charizard] : HP - " + wildPokemon_damage + "points.");
        if(getHp() - wildPokemon_damage > 0)
            setHp(getHp() - wildPokemon_damage);
        else
            setHp(0);
    }
}
