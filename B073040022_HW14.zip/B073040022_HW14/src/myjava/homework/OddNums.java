package myjava.homework;
import java.io.FileWriter;
import java.io.IOException;
import java.util.stream.DoubleStream;
import java.util.stream.IntStream;
import static java.lang.StrictMath.sqrt;

public class OddNums implements Runnable{
    private int[] oddNums;
    private FileWriter fw;
    public OddNums(int[] oddNums,FileWriter fw) {
        this.oddNums=oddNums;
        this.fw=fw;
    }

    @Override
    public void run() {
        synchronized(fw){
            try {
                fw.write("Odd number: " + IntStream.of(oddNums).filter(value -> value % 2 != 0).count() + "\n");//Lambda
                fw.write("------------------------------\n");
            }
            catch (IOException e) {
                System.out.println("Cannot write to file");
            }
        }
        try {
            Thread.sleep(300);
        } catch (Exception ignored) {

        }
        synchronized(fw){
            try {
                fw.write("Odd number average: " + IntStream.of(oddNums).filter(value -> value % 2 != 0).average().getAsDouble() + "\n");//Lambda
                fw.write("------------------------------\n");
            }
            catch (IOException e) {
                System.out.println("Cannot write to file");
            }
        }
        try {
            Thread.sleep(300);
        } catch (Exception ignored) {

        }
        synchronized(fw){
            try {
                fw.write("Odd number max: " + IntStream.of(oddNums).filter(value -> value % 2 != 0).max().getAsInt() + "\n");//Lambda
                fw.write("------------------------------\n");
            }
            catch (IOException e) {
                System.out.println("Cannot write to file");
            }
        }
        try {
            Thread.sleep(300);
        } catch (Exception ignored) {

        }
        synchronized(fw){
            try {
                fw.write("Odd number min: " + IntStream.of(oddNums).filter(value -> value % 2 != 0).min().getAsInt() + "\n");//Lambda
                fw.write("------------------------------\n");
            }
            catch (IOException e) {
                System.out.println("Cannot write to file");
            }
        }
        try {
            Thread.sleep(350);
        } catch (Exception ignored) {

        }
        synchronized(fw){
            try {
                double avg_sqr = (IntStream.of(oddNums).filter(value -> value%2!=0).average().getAsDouble()) * (IntStream.of(oddNums).filter(value -> value%2!=0).average().getAsDouble());//Lambda//β^2
                double sum = 0;
                double[] doubles = new double[oddNums.length];
                for(int i = 0; i < oddNums.length; i++) {
                    doubles[i] = oddNums[i];
                }
                sum = DoubleStream.of(doubles).filter(value -> value%2!=0).reduce(0.0,(x, y) -> x + (y * y - avg_sqr));//Lambda//Σ(α2−β2)
                sum = sqrt(sum);//√Σ(α2−β2)
                fw.write("Odd number formula:" + sum + "\n");
                fw.write("------------------------------\n");
            }
            catch (IOException e){
                System.out.println("Cannot write to file");
            }
        }
    }
}
