package com.javacodegeeks.patterns.factorymethodpattern;

public class OrderXMLParser implements XMLParser{//實體物件

	@Override
	public String parse() {
		System.out.println("Parsing order XML...");
		return "Order XML Message";
	}

}

