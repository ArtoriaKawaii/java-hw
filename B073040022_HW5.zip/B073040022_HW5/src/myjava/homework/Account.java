//Represents a bank account
package myjava.homework;

public class Account {
	private int accountNumber;
	private int pin;
	private int totalBalance;
	private int debt;
	private char creditLevel;
	public Account(int accountNumber, int pin, int totalBalance, int debt, char creditLevel){
        this.accountNumber = accountNumber;
        this.pin = pin;
        this.totalBalance = totalBalance;
        this.debt = debt;
        this.creditLevel = creditLevel;
    }
	public boolean validatePIN(int pin){
        return(this.pin == pin);
    }
	public int getAccountNumber(){
        return this.accountNumber;
    }
	public int getTotalBalance(){
        return this.totalBalance;
    }
    public char getCreditLevel(){
        return this.creditLevel;
	}
    public int getDebt(){
        return  this.debt;
    }
    public void setTotalBalance(int totalBalance){
        this.totalBalance = totalBalance;
    }
    public void setDebt(int debt) {
        this.debt = debt;
    }
}
