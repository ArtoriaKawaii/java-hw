// Represents a balance inquiry ATM transaction
package myjava.homework;

public class BalanceInquiry extends Transaction {
    public BalanceInquiry(int accountNumber){
        super(accountNumber);
    }
    public void execute(){
        output.displayMessageLine("Balance information");
        output.displayMessageLine("Total balance : " + ATM.bankDatabase.getTotalBalance(getAccountNumber()) + "\n");
    }
}
