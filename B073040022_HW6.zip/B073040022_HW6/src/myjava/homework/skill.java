package myjava.homework;

public interface skill {
    int attack_skill();
    int defense_skill();
    int buff_skill();
}
