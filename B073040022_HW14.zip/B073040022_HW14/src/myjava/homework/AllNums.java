package myjava.homework;
import java.io.FileWriter;
import java.io.IOException;
import java.util.stream.DoubleStream;
import java.util.stream.IntStream;
import static java.lang.StrictMath.sqrt;

public class AllNums implements Runnable{
    private int[] allNums;
    private FileWriter fw;
    public AllNums(int[] allNums, FileWriter fw) {
        this.allNums = allNums;
        this.fw = fw;
    }
    @Override
    public void run() {
        synchronized(fw){
            try {
                fw.write("All number: " + IntStream.of(allNums).count() + "\n");//Lambda
            }
            catch (IOException e){
                System.out.println("Cannot write to file.");
            }
        }
        try{
            Thread.sleep(100);
        } catch (Exception ignored) {

        }
        synchronized(fw){
            try {
                fw.write("All number average: " + IntStream.of(allNums).average().getAsDouble() + "\n");//Lambda
            }
            catch (IOException e){
                System.out.println("Cannot write to file.");
            }
        }
        try{
            Thread.sleep(250);
        } catch (Exception ignored) {

        }
        synchronized(fw){
            try {
                fw.write("All number max: " + IntStream.of(allNums).max().getAsInt() + "\n");//Lambda
            }
            catch (IOException e){
                System.out.println("Cannot write to file.");
            }
        }
        try{
            Thread.sleep(260);
        } catch (Exception ignored) {

        }
        synchronized(fw){
            try {
                fw.write("All number min: " + IntStream.of(allNums).min().getAsInt() + "\n");//Lambda
            }
            catch (IOException e){
                System.out.println("Cannot write to file.");
            }
        }
        try{
            Thread.sleep(300);
        } catch (Exception ignored) {

        }
        synchronized(fw){
            try {
                double avg_sqr = (IntStream.of(allNums).average().getAsDouble()) * (IntStream.of(allNums).average().getAsDouble());//Lambda//β^2
                double sum = 0;
                double[] doubles = new double[allNums.length];
                for(int i = 0; i < allNums.length; i++) {
                    doubles[i] = allNums[i];
                }
                sum = DoubleStream.of(doubles).reduce(0.0,(x, y) -> x + (y * y - avg_sqr));//Lambda//Σ(α2−β2)
                sum = sqrt(sum);//√Σ(α2−β2)
                fw.write("All number formula:" + sum + "\n");
            }
            catch (IOException e){
                System.out.println("Cannot write to file.");
            }
        }
    }
}
