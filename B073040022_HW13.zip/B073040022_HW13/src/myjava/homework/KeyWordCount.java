package myjava.homework;

public class KeyWordCount {
    private static KeyWordCount kc;

    private int count = 0;
    private KeyWordCount(){

    }

    public static synchronized KeyWordCount getCountObject(){
        if(kc == null){
            kc = new KeyWordCount();
        }
        return kc;
    }

    public synchronized void  addCount(int count){
        System.out.println("找到關鍵字個數："+count);
        this.count += count;
    }

    public int getCount() {
        return count;
    }

    //un-used accessor / mutator
    public void setCount(int count) {
        this.count = count;
    }
}
