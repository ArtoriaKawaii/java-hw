// Abstract superclass Transaction represents an ATM transaction
package myjava.homework;

public abstract class Transaction {
	private int accountNumber;
	protected Screen output = new Screen();
	protected Keypad input = new Keypad();
	public Transaction(int accountNumber){
		this.accountNumber = accountNumber;
	}
	public int getAccountNumber(){
		return accountNumber;
    }
	public abstract void execute();
}
