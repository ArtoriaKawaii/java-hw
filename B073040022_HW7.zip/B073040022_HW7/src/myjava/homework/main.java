package myjava.homework;

import com.opencsv.CSVReader;
import com.opencsv.CSVReaderBuilder;

import javafx.scene.chart.Chart;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.labels.PieSectionLabelGenerator;
import org.jfree.chart.labels.StandardPieSectionLabelGenerator;
import org.jfree.chart.plot.PiePlot;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.data.general.DefaultPieDataset;
import org.jfree.ui.ApplicationFrame;
import org.jfree.ui.RefineryUtilities;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.text.DecimalFormat;
import java.util.*;

public class main {
    public static class BarChart extends ApplicationFrame{
        //ApplicationFrame - A base class for creating the main frame for simple applications.
        //The frame listens for window closing events, and responds by shutting down the JVM. This is OK for small demo applications
        private DefaultCategoryDataset dataset = new DefaultCategoryDataset();
        public BarChart(String fileName){
            super(fileName);
        }
    }
    public static class PieChart3D extends ApplicationFrame{
        //ApplicationFrame - A base class for creating the main frame for simple applications.
        //The frame listens for window closing events, and responds by shutting down the JVM. This is OK for small demo applications
        private DefaultPieDataset dataset = new DefaultPieDataset();
        public PieChart3D(String fileName){
            super(fileName);
        }
    }
    public static void main(String[] args){
        Map<String, ArrayList<String>> list  = new HashMap<>();
        try {
            FileReader fr = new FileReader("query_result.csv");
            CSVReader csvReader = new CSVReaderBuilder(fr).withSkipLines(1).build();
            String[] nextRecord;
            while((nextRecord = csvReader.readNext()) != null) {//add to hash map
                /*System.out.print("id = " + nextRecord[0]);
                System.out.print("\tproduct_type = " + nextRecord[1]);
                System.out.println("\tid_gender = " + nextRecord[2]);*///Check csv data
                ArrayList<String> arrayList = new ArrayList<>();
                String key = nextRecord[0];//id
                arrayList.add(nextRecord[1]);//product_type
                arrayList.add(nextRecord[2]);//id_gender
                if(list.containsKey(key)) {
                    list.get(key).addAll(arrayList);
                    continue;
                }
                list.put(key, arrayList);
            }
            fr.close();
            /*for(String key : list.keySet()){//through list
                System.out.println(key);
                for(String x : list.get(key))
                    System.out.print(x + "\t");
                System.out.println();
            }*///Check list data
        }catch(FileNotFoundException e1){
            System.out.println("FileNotFoundException");//Should not happen
        }catch(IOException e2){
            System.out.println("IOException");//Should not happen
        }catch (NullPointerException e3){
            System.out.println("NullPointerException");//Should not happen
        }
        boolean flag = true;
        Scanner input = new Scanner(System.in);
        while(flag) {
            try {
                System.out.println("Which data of Market do you want Graphic ? (1.Products 2.Id_gender 3.Id purchase history)");
                int option1 = input.nextInt();
                if(option1 > 3 || option1 < 1){
                    System.out.println("Input error.");
                    continue;
                }
                switch (option1){
                    case 1: {//Products
                        System.out.println("Which kind of Graph ? (1.Bar Chart 2.Pie Chart(3D))");
                        int option2 = input.nextInt();
                        if(option2 > 2 || option2 < 1){
                            System.out.println("Input error.");
                            continue;
                        }
                        int[] product = new int[3];//represents the quantity of product A, B, C
                        for(String key : list.keySet()){//through list
                            for(String x : list.get(key)) {
                                switch (x){
                                    case "Product_A":
                                        product[0]++;
                                        break;
                                    case "Product_B":
                                        product[1]++;
                                        break;
                                    case "Product_C":
                                        product[2]++;
                                        break;
                                }
                            }
                        }
                        switch (option2) {
                            case 1: {
                                //bar chart
                                BarChart barChart = new BarChart("Product BarChart");
                                barChart.dataset.setValue(product[0], "Product Compare", "ProductA");
                                barChart.dataset.setValue(product[1], "Product Compare", "ProductB");
                                barChart.dataset.setValue(product[2], "Product Compare", "ProductC" );
                                JFreeChart chart = ChartFactory.createBarChart(
                                        "Products sale situation",//chart title
                                        "Product Compare",//chart category(row) label
                                        "Quantity",//chart value(column) label
                                        barChart.dataset,//use dataset
                                        PlotOrientation.VERTICAL,//垂直長條圖
                                        false,//legend(圖例)
                                        true,//tooltips(工具提示)
                                        true);//urls(網址)
                                barChart.setContentPane(new ChartPanel(chart));//parameter is a Container object
                                //Container object is a component that can contain other AWT components.
                                // A Component(abstract) is an object having a graphical representation that can be displayed on the screen and that can interact with the user.
                                barChart.setSize(1000, 600);
                                RefineryUtilities.centerFrameOnScreen(barChart);//Positions the specified frame in the middle of the screen.
                                barChart.setVisible(true);
                                barChart.setAlwaysOnTop(true);
                                return;
                            }
                            case 2: {
                                //pie chart
                                PieChart3D pieChart3D = new PieChart3D("Product PieChart3D");
                                pieChart3D.dataset.setValue("ProductA", product[0]);
                                pieChart3D.dataset.setValue("ProductB", product[1]);
                                pieChart3D.dataset.setValue("ProductC", product[2]);
                                JFreeChart chart = ChartFactory.createPieChart3D(
                                        "Products sale situation",//chart title
                                        pieChart3D.dataset,//use dataset
                                        true,//legend(圖例)
                                        true,//tooltips(工具提示)
                                        false);//urls(網址)
                                PiePlot plot = (PiePlot) chart.getPlot();
                                PieSectionLabelGenerator label = new StandardPieSectionLabelGenerator(
                                        "{0}: {1} ({2})",//label format (KEY: VALUE VALUE_IN_PERCENT)
                                        new DecimalFormat("0"),//VALUE format
                                        new DecimalFormat("0.00%"));//VALUE_IN_PERCENT format
                                plot.setLabelGenerator(label);
                                //plot.setSectionLabelType(int type);
                                //used to set section label type(NO_LABELS, NAME_LABELS, VALUE_LABELS, PERCENT_LABELS, NAME_AND_VALUE_LABELS, NAME_AND_PERCENT_LABELS, VALUE_AND_PERCENT_LABELS)
                                //cannot use. Maybe is the version of jfreechart too old?
                                pieChart3D.setContentPane(new ChartPanel(chart));//parameter is a Container object
                                //Container object is a component that can contain other AWT components.
                                // A Component(abstract) is an object having a graphical representation that can be displayed on the screen and that can interact with the user.
                                pieChart3D.setSize(1000, 600);
                                RefineryUtilities.centerFrameOnScreen(pieChart3D);//Positions the specified frame in the middle of the screen.
                                pieChart3D.setVisible(true);
                                pieChart3D.setAlwaysOnTop(true);
                                return;
                            }
                        }
                    }
                    case 2: {//Id_gender
                        System.out.println("Which kind of Graph ? (1.Bar Chart 2.Pie Chart(3D))");
                        int option2 = input.nextInt();
                        if(option2 > 2 || option2 < 1){
                            System.out.println("Input error.");
                            continue;
                        }
                        int[] gender = new int[2];//represents the quantity of gender F, M
                        for(String key : list.keySet()){//through list
                            for(String x : list.get(key)) {
                                switch (x){
                                    case "F":
                                        gender[0]++;
                                        break;
                                    case "M":
                                        gender[1]++;
                                        break;
                                }
                            }
                        }
                        switch (option2) {
                            case 1: {
                                //bar chart
                                BarChart barChart = new BarChart("id_gender BarChart");
                                barChart.dataset.setValue(gender[0], "id_gender Compare", "Female");
                                barChart.dataset.setValue(gender[1], "id_gender Compare", "Male");
                                JFreeChart chart = ChartFactory.createBarChart(
                                        "id_gender",//chart title
                                        "id_gender Compare",//chart category(row) label
                                        "Quantity",//chart value(column) label
                                        barChart.dataset,//use dataset
                                        PlotOrientation.VERTICAL,//垂直長條圖
                                        false,//legend(圖例)
                                        true,//tooltips(工具提示)
                                        true);//urls(網址)
                                barChart.setContentPane(new ChartPanel(chart));//parameter is a Container object
                                //Container object is a component that can contain other AWT components.
                                // A Component(abstract) is an object having a graphical representation that can be displayed on the screen and that can interact with the user.
                                barChart.setSize(1000, 600);
                                RefineryUtilities.centerFrameOnScreen(barChart);//Positions the specified frame in the middle of the screen.
                                barChart.setVisible(true);
                                barChart.setAlwaysOnTop(true);
                                return;
                            }
                            case 2: {
                                //pie chart
                                PieChart3D pieChart3D = new PieChart3D("id_gender PieChart3D");
                                pieChart3D.dataset.setValue("Female", gender[0]);
                                pieChart3D.dataset.setValue("Male", gender[1]);
                                JFreeChart chart = ChartFactory.createPieChart3D(
                                        "id_gender",//chart title
                                        pieChart3D.dataset,//use dataset
                                        true,//legend(圖例)
                                        true,//tooltips(工具提示)
                                        false);//urls(網址)
                                PiePlot plot = (PiePlot) chart.getPlot();
                                PieSectionLabelGenerator label = new StandardPieSectionLabelGenerator(
                                        "{0}: {1} ({2})",//label format (KEY: VALUE VALUE_IN_PERCENT)
                                        new DecimalFormat("0"),//VALUE format
                                        new DecimalFormat("0.00%"));//VALUE_IN_PERCENT format
                                plot.setLabelGenerator(label);
                                //plot.setSectionLabelType(int type);
                                //used to set section label type(NO_LABELS, NAME_LABELS, VALUE_LABELS, PERCENT_LABELS, NAME_AND_VALUE_LABELS, NAME_AND_PERCENT_LABELS, VALUE_AND_PERCENT_LABELS)
                                //cannot use. Maybe is the version of jfreechart too old?
                                pieChart3D.setContentPane(new ChartPanel(chart));//parameter is a Container object
                                //Container object is a component that can contain other AWT components.
                                // A Component(abstract) is an object having a graphical representation that can be displayed on the screen and that can interact with the user.
                                pieChart3D.setSize(1000, 600);
                                RefineryUtilities.centerFrameOnScreen(pieChart3D);
                                pieChart3D.setVisible(true);
                                pieChart3D.setAlwaysOnTop(true);
                                return;
                            }
                        }
                    }
                    case 3: {//Id purchase history
                        System.out.println("Input ID : ");
                        String id = input.next();
                        int[] product = new int[3];//represents the quantity of product A, B, C
                        if(list.containsKey(id)) {
                            for (String x : list.get(id)){
                                switch (x){
                                    case "Product_A":
                                        product[0]++;
                                        break;
                                    case "Product_B":
                                        product[1]++;
                                        break;
                                    case "Product_C":
                                        product[2]++;
                                        break;
                                }
                            }
                        }
                        else{
                            System.out.println("Data not found.");
                            return;
                        }
                        //bar chart
                        BarChart barChart = new BarChart("ID Product BarChart");
                        barChart.dataset.setValue(product[0], "Products", "ProductA");
                        barChart.dataset.setValue(product[1], "Products", "ProductB");
                        barChart.dataset.setValue(product[2], "Products", "ProductC" );
                        JFreeChart chart = ChartFactory.createBarChart(
                                id + " purchase history",//chart title
                                "Products",//chart category(row) label
                                "Quantity",//chart value(column) label
                                barChart.dataset,//use dataset
                                PlotOrientation.VERTICAL,//垂直長條圖
                                false,//legend(圖例)
                                true,//tooltips(工具提示)
                                true);//urls(網址)
                        barChart.setContentPane(new ChartPanel(chart));//parameter is a Container object
                        //Container object is a component that can contain other AWT components.
                        // A Component(abstract) is an object having a graphical representation that can be displayed on the screen and that can interact with the user.
                        barChart.setSize(1000, 600);
                        RefineryUtilities.centerFrameOnScreen(barChart);//Positions the specified frame in the middle of the screen.
                        barChart.setVisible(true);
                        barChart.setAlwaysOnTop(true);
                        return;
                    }
                }
            }catch(InputMismatchException e){
                System.out.println("Input error.");
                input.nextLine();//clean buffer
            }
        }
    }

}
