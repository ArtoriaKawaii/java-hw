package myjava.homework_part1;

import java.util.Scanner;
import java.util.Vector;

public class Controller {
    public static void main(String[] args) {
        int option, count = 0, studentNum;
        Vector<StudentInformation> studentList = new Vector<>();
        Scanner scan = new Scanner(System.in);
        while(true) {
            while(true) {
                System.out.println("Type 1: add a student's data(student ID, student name and score).");
                System.out.println("Type 2: show student's data.");
                System.out.println("Type 3: show all student's data.");
                System.out.println("Enter other NUMBER to exit.");
                if(scan.hasNextInt()) {
                    option = scan.nextInt();
                    break;
                }
                else
                    System.out.println("Invalid type. Enter type again.");
                    scan.next();
            }
            switch(option) {
                case 1:
                    System.out.println("Add new student's data :");
                    count++;
                    studentList.add(new StudentInformation());
                    System.out.print("Student ID :");
                    studentList.elementAt(count - 1).setID(scan.next());
                    System.out.print("Student name :");
                    studentList.elementAt(count - 1).setName(scan.next());
                    while (true) {
                        System.out.print("Score :");
                        if(scan.hasNextInt()){
                            int score = scan.nextInt();
                            if (score >= 0 && score <= 100) {
                                studentList.elementAt(count - 1).setScore(score);
                                break;
                            }
                        }
                        else
                            scan.next();
                        System.out.println("Invalid score. Enter Score again.");
                    }
                    System.out.printf("This is student %d\n\n", count);
                    break;
                case 2 :
                    while(true) {
                        System.out.println("To show which student's information");
                        if(scan.hasNextInt()) {
                            studentNum = scan.nextInt();
                            break;
                        }
                        else {
                            System.out.println("Invalid number. Enter again.");
                            scan.next();
                        }
                    }
                    if(studentNum > studentList.size() || studentNum <= 0)
                        System.out.println("Data not found.");
                    else{
                        studentList.elementAt(studentNum - 1).show_data();
                        System.out.println("This is student " + studentNum);
                    }
                    break;
                case 3 :
                    int passNum = 0, failNum = 0;
                    System.out.println("====Student's data====");
                    for(int i = 0; i < studentList.size(); i++){
                        System.out.println("Number :" + (i + 1));
                        studentList.elementAt(i).show_data();
                        if(studentList.elementAt(i).getScore() >= 60)
                            passNum++;
                        else
                            failNum++;
                    }
                    System.out.println("======================");
                    System.out.println("Pass :" + passNum);
                    System.out.println("No Pass :" + failNum);
                    break;
                default :
                    return ;
            }
        }
    }
}
