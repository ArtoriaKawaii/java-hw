package PokemonData;

public class Moltres extends Pokemon {
    private int Level = 10 + rand.nextInt(41);//10~50
    private int Fluctuation = rand.nextInt(15);
    private int CorrectHeight = rand.nextInt(151);
    private int CorrectWeight = rand.nextInt(9001);
    public Moltres(){
        Name = "Moltres";
        HP *= Level;
        ATK *= Level;
        DEF *= Level;
        HP = HP - Fluctuation + rand.nextInt(Fluctuation * 2 + 1);
        ATK = ATK - Fluctuation + rand.nextInt(Fluctuation * 2 + 1);
        DEF = DEF - Fluctuation + rand.nextInt(Fluctuation * 2 + 1);
        Height += CorrectHeight;//50~200cm(0.5~2m)
        Weight += CorrectWeight;//1000~10000g(1~10kg)
    }
}
