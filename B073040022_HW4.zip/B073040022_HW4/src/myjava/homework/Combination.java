package myjava.homework;

public class Combination extends fourStarGame{
    public void checkOfWin(){
        for(Integer win : getWinNums()){
            flag = -1;
            for(Integer user : getUserNums()){
                if(win == user){
                    flag = 1;
                    break;
                }
            }
            if(flag == -1){
                System.out.println("**You lose.");
                return;
            }
        }
        System.out.println("**You win.");
    }
}
