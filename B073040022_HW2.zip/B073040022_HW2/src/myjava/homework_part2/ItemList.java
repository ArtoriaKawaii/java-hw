package myjava.homework_part2;

import java.util.ArrayList;

public class ItemList {
    private ArrayList<String> id = new ArrayList<>();

    public ItemList(){
//        id = null; can't assign null to an object
    }
    public void addItem(String itemName){
        id.add(itemName);
    }
    public void remove(String itemName){
        if(id.contains(itemName))
            id.remove(itemName);
        else
            System.out.println("Item not found.");
    }
    public void printList(){
        for(int i = 0; i < id.size(); i++)
            System.out.printf("%d : %s\n", i + 1, id.get(i));
    }
}
