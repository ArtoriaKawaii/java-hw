// Represents the bank account information database
package myjava.homework;

public class BankDatabase {
	
	private Account[] accounts; // array of Accounts
	private int count;
    // no-argument BankDatabase constructor initializes accounts
	public BankDatabase () {
		accounts = new Account[4];  // just 4 accounts for testing
		accounts[0] = new Account(111, 222, 5000,0,'A');
		accounts[1] = new Account(222, 333, 4000,0,'B');
		accounts[2] = new Account(333, 444, 3000,0,'C');
		accounts[3] = new Account(444, 555, 2000,0,'D');
		count = 4;
	}
	
	public boolean authenticateUser(int accountNumber, int pin){
		int flag = 0;
		for(int i = 0; i < count; i++)
			if(accountNumber == accounts[i].getAccountNumber() && accounts[i].validatePIN(pin))
				flag = 1;
		return (flag == 1);
	}
	public int getTotalBalance(int accountNumber){
		int index;
		for(index = 0; index < count; index++)
			if(accounts[index].getAccountNumber() == accountNumber)
				break;
		return accounts[index].getTotalBalance();
	}
	public char getCreditLevel(int accountNumber){
		int index;
		for(index = 0; index < count; index++)
			if(accounts[index].getAccountNumber() == accountNumber)
				break;
		return accounts[index].getCreditLevel();
	}
	public int getDebt(int accountNumber){
		int index;
		for(index = 0; index < count; index++)
			if(accounts[index].getAccountNumber() == accountNumber)
				break;
		return accounts[index].getDebt();
	}
	public void setTotalBalance(int accountNumber, int totalBalance){
		int index;
		for(index = 0; index < count; index++)
			if(accounts[index].getAccountNumber() == accountNumber)
				break;
		accounts[index].setTotalBalance(totalBalance);
	}
	public void setDebt(int accountNumber, int debt){
		int index;
		for(index = 0; index < count; index++)
			if(accounts[index].getAccountNumber() == accountNumber)
				break;
		accounts[index].setDebt(debt);
	}
}
