package myjava.homework;

import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Random;
import java.util.Scanner;

public class Main {
    public static void main(String[] args){
        try {
            FileWriter fw = new FileWriter("File.txt");
            ArrayList<Integer> allNums = new ArrayList<>();
            Scanner keyboard = new Scanner(System.in);
            int range, quantity;
            System.out.println("Please input your random range :");
            range = keyboard.nextInt();
            int[] records = new int[range+1];//0~range
            for(int x : records)
                x = 0;
            System.out.println("Please input how many distinct number :");
            quantity = keyboard.nextInt();
            for(int i = 0; i < quantity; i++){//generate n random distinct numbers
                Random rnd = new Random();
                int num = rnd.nextInt(range+1);//0~range
                if(records[num] != 0){
                    i--;
                }
                else{
                    allNums.add(num);
                    records[num]++;
                }
            }
            Collections.sort(allNums);
            int[] all = new int[quantity];
            fw.write("Random numbers :\n");
            for(int i = 0; i < quantity; i++) {
                all[i] = allNums.get(i);
                fw.write(all[i] + ", ");
            }
            fw.write("\n-------------------------------------\n");
            AllNums an = new AllNums(all, fw);
            OddNums od = new OddNums(all, fw);
            EvenNums en = new EvenNums(all, fw);
            Thread all_t = new Thread(an);
            Thread odd_t = new Thread(od);
            Thread even_t = new Thread(en);
            all_t.start();
            odd_t.start();
            even_t.start();
            all_t.join();
            odd_t.join();
            even_t.join();
            System.out.println("Done!");
            fw.close();
        }catch (IOException ex){
            System.out.println("Cannot open / create File.txt");
        }catch (InterruptedException ex){
            System.out.println("Thread interrupted.");
        }
    }
}
