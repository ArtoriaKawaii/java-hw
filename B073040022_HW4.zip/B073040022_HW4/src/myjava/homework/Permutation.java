package myjava.homework;

public class Permutation extends fourStarGame{
    public void checkOfWin(){
        for(int i = 0; i < STARS; i++){
            if(!getWinNums().get(i).equals(getUserNums().get(i))){
                System.out.println("**You lose.");
                return;
            }
        }
        System.out.println("**You win.");
    }
}
