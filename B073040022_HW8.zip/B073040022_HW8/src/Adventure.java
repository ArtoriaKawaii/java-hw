import PokemonData.*;

import java.util.*;

public class Adventure {
    public Adventure(){

    }
    public List<Pokemon> Encounter(int map){
        ArrayList<Pokemon> encounterList = new ArrayList<>();
        Random rand = new Random();
        switch(map){
            case 1:{
                for(int i = 0; i < 4 + rand.nextInt(4); i++) {//4~7 pokemons
                    int randNum = rand.nextInt(100) + 1;//1~100
                    if (randNum > 50) //51~100 -> 50%
                        encounterList.add(new Rattata());
                    else if (randNum > 20) //21~50 -> 30%
                        encounterList.add(new Pikachu());
                    else if (randNum > 5) //6~20 -> 15 %
                        encounterList.add(new Gloom());
                    else //1~5 -> 5 %
                        encounterList.add(new Zapdos());
                }
                break;
            }
            case 2:{
                for(int i = 0; i < 4 + rand.nextInt(4); i++) {//4~7 pokemons
                    int randNum = rand.nextInt(100) + 1;//1~100
                    if (randNum > 50) //51~100 -> 50%
                        encounterList.add(new Pidgey());
                    else if (randNum > 20) //21~50 -> 30%
                        encounterList.add(new Eevee());
                    else if (randNum > 5) //6~20 -> 15 %
                        encounterList.add(new Arcanine());
                    else //1~5 -> 5 %
                        encounterList.add(new Moltres());
                }
                break;
            }
            default://should not happen
        }
        return encounterList;
    }
    public <T extends Pokemon>List<T> CatchScenes(List<T> list){
        ArrayList<T> catchList = new ArrayList<>();
        Scanner input = new Scanner(System.in);
        Random rand = new Random();
        for(int i = 0; i < list.size(); i++){//Pokemons
            System.out.print(list.get(i).toString());//print pokemon status
            int round = 1;
            while(true){//Rounds
                try {
                    System.out.println("\nRound : " + round);
                    System.out.print("Choose your action (1: Catch, 2: Runaway) : ");
                    int action = input.nextInt();
                    if(action != 1 && action != 2){
                        System.out.println("Invalid action.");
                        continue;
                    }
                    if(action == 1){
                            System.out.println("Throw Poke Ball...");
                            int randNum = rand.nextInt(100);//0~99
                            int catchBonus = 0;
                            if(randNum < 5)//0~4
                                catchBonus += 10;
                            else if(randNum < 20)//5~19
                                catchBonus += 5;
                            if(list.get(i).Catch(catchBonus)){
                                System.out.println("Catch success!\n");
                                catchList.add(list.get(i));
                                break;//next pokemon
                            }
                            else{
                                System.out.println("Catch failure...");
                                if(list.get(i).Runaway(round)){
                                    System.out.println("\nOh no! The wild pokemon flee!\n");
                                    break;//next pokemon
                                }
                            }
                        }
                    else if(action == 2) {//you run away
                        System.out.println("Runaway...\n");
                        break;//next pokemon
                    }
                    round++;
                }catch (InputMismatchException e){
                    System.out.println("Invalid input. Enter integers");
                    input.nextLine();
                }
            }
        }
        return catchList;
    }
}
