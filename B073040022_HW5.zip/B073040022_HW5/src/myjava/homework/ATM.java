package myjava.homework;

public class ATM {
    private boolean userAuthenticated;
    public static BankDatabase bankDatabase;
    private Screen output = new Screen();
    private Keypad input = new Keypad();

    public ATM(){

    }
    public void run(){
        while(true){
            bankDatabase = new BankDatabase();
            int accountNumber;
            int pin;
            output.displayMessageLine("Welcome!");
            output.displayMessage("Please enter your account number : ");
            accountNumber = input.getInput();
            output.displayMessage("Please enter your pin : ");
            pin = input.getInput();
            if(accountNumber == -1 || pin == -1)
                output.displayMessageLine("Input error.\n");
            else if(!bankDatabase.authenticateUser(accountNumber, pin))
                output.displayMessageLine("Account number or Pin error.\n");
            else{
                while(true) {
                    int choice;
                    output.displayMessageLine("Main_menu : ");
                    output.displayMessageLine("1.View my balance");
                    output.displayMessageLine("2.Withdraw");
                    output.displayMessageLine("3.Deposit");
                    output.displayMessageLine("4.Loan");
                    output.displayMessageLine("5.Exit");
                    while (true) {
                        output.displayMessage("Enter a choice : ");
                        choice = input.getInput();
                        if(choice <= 5 && choice >= 1)
                            break;
                        output.displayMessageLine("Input error. Please Enter the right option.");
                    }
                    switch (choice) {
                        case 1:
                            new BalanceInquiry(accountNumber).execute();
                            break;
                        case 2:
                            new Withdrawal(accountNumber).execute();
                            break;
                        case 3:
                            new Deposit(accountNumber).execute();
                            break;
                        case 4:
                            new Loan(accountNumber).execute();
                            break;
                    }
                    if(choice == 5)
                        break;
                }
            }
        }
    }
	
}
